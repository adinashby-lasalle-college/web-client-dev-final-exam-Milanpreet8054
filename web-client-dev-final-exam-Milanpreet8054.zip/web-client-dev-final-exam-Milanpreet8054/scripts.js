document.addEventListener("DOMContentLoaded", function () {
    const scrollTopButton = document.getElementById("scroll-top");
    const addProjectButton = document.getElementById("add-project");
    const toggleResourcesButton = document.getElementById("toggle-resources");
    const resourcesList = document.getElementById("resources");
    const form = document.querySelector("form");

    window.addEventListener("scroll", () => {
        if (window.scrollY > 200) {
            scrollTopButton.style.display = "block";
        } else {
            scrollTopButton.style.display = "none";
        }
    });

    scrollTopButton.addEventListener("click", () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });

    addProjectButton.addEventListener("click", () => {
        const tableBody = document.querySelector("table tbody");
        const newRow = document.createElement("tr");

        newRow.innerHTML = `
            <td>Sample Project</td>
            <td>Newly Added Description</td>
            <td>${new Date().toISOString().split("T")[0]}</td>
        `;
        tableBody.appendChild(newRow);
    });

    toggleResourcesButton.addEventListener("click", () => {
        resourcesList.style.display =
            resourcesList.style.display === "none" ? "block" : "none";
    });

    form.addEventListener("submit", (event) => {
        event.preventDefault();

        const name = document.getElementById("name");
        const email = document.getElementById("email");
        const message = document.getElementById("message");

        if (!name.value || !email.value || !message.value) {
            alert("Please fill out all fields!");
        } else {
            alert("Thank you for your message!");
            form.reset();
        }
    });
});

// jQuery Enhancements
$(document).ready(function () {
    $("main").hide().fadeIn(1500);

    $("nav ul").hover(
        function () {
            $(this).stop().slideDown(300);
        },
        function () {
            $(this).stop().slideUp(300);
        }
    );

    $("#toggle-resources").click(function () {
        $("#resources").slideToggle(500);
    });

    $("form").submit(function (e) {
        e.preventDefault();

        let isValid = true;
        $(this)
            .find("input, textarea")
            .each(function () {
                if (!$(this).val()) {
                    isValid = false;
                    $(this).css("border-color", "red");
                } else {
                    $(this).css("border-color", "#ccc");
                }
            });

        if (isValid) {
            alert("Thank you for your message!");
            this.reset();
        } else {
            alert("Please fill out all fields correctly.");
        }
    });
});
